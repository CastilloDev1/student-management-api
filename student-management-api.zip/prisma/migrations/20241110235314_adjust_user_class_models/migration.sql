/*
  Warnings:

  - You are about to drop the column `cost` on the `subjects` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE `subjects` DROP COLUMN `cost`;
