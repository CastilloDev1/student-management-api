import express from 'express';
import userRoutes from './routes/UserRoutes';
import subjectRoutes from './routes/SubjectRoutes';
import classRoutes from './routes/ClassRoutes';
import classEnrollmentRoutes from './routes/ClassEnrollmentRoutes';

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use('/api', userRoutes);
app.use('/api', subjectRoutes);
app.use('/api', classRoutes);
app.use('/api', classEnrollmentRoutes);

app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});