import { Request, Response } from 'express';
import { ClassUseCase } from '../use-cases/ClassUseCase';

const classUseCase = new ClassUseCase();

export class ClassController {
  async createClass(req: Request, res: Response): Promise<void> {
    try {
      const newClass = await classUseCase.createClass(req.body);
      res.status(201).json(newClass);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  }

  async getAllClasses(req: Request, res: Response): Promise<void> {
    try {
      const classes = await classUseCase.getAllClasses();
      res.status(200).json(classes);
    } catch (error: any) {
      res.status(500).json({ message: 'Error al obtener las clases', error });
    }
  }

  async getClassById(req: Request, res: Response): Promise<any> {
    try {
      const classData = await classUseCase.getClassById(req.params.id);
      if (!classData) {
        return res.status(404).json({ message: 'Clase no encontrada' });
      }
      res.status(200).json(classData);
    } catch (error: any) {
      res.status(500).json({ message: 'Error al obtener la clase', error });
    }
  }

  async updateClass(req: Request, res: Response): Promise<any> {
    try {
      const updatedClass = await classUseCase.updateClass(req.params.id, req.body);
      if (!updatedClass) {
        return res.status(404).json({ message: 'Clase no encontrada' });
      }
      res.status(200).json(updatedClass);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  }

  async deleteClass(req: Request, res: Response): Promise<any> {
    try {
      const deletedClass = await classUseCase.deleteClass(req.params.id);
      if (!deletedClass) {
        return res.status(404).json({ message: 'Clase no encontrada' });
      }
      res.status(200).json({ message: 'Clase eliminada' });
    } catch (error: any) {
      res.status(500).json({ message: 'Error al eliminar la clase', error });
    }
  }

  async getClassesWithDetails(req: Request, res: Response): Promise<void> {
    try {
      const classes = await classUseCase.getClassesWithDetails();
      res.status(200).json(classes);
    } catch (error: any) {
      res.status(500).json({ message: 'Error al obtener los detalles de las clases', error });
    }
  }

  async getClassWithEnrollments(req: Request, res: Response): Promise<void> {
    try {
      const classId = req.params.classId;
      const classDetails = await classUseCase.getClassWithEnrollments(classId);
      res.status(200).json(classDetails);
    } catch (error: any) {
      res.status(500).json({ message: 'Error al obtener los detalles de la clase', error });
    }
  }
}
