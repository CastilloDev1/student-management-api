import { Request, Response } from 'express';
import { UserUseCase } from '../use-cases/UserUseCase';

const userUseCase = new UserUseCase();

export class UserController {

  getAllUsers = async (req: Request, res: Response) => {
    try {
      const users = await userUseCase.getAllUsers();
      res.status(200).json({message: 'usuarios encontrados', data: users});
    } catch (error) {
      res.status(500).json({ message: 'Error al obtener usuarios', error });
    }
  }

  async getUserById(req: Request, res: Response) {
    try {
      const userId = req.params.id;
      const user = await userUseCase.getUserById(userId);
      if (user) {
        res.status(200).json(user);
      } else {
        res.status(404).json({ message: 'Usuario no encontrado' });
      }
    } catch (error) {
      res.status(500).json({ message: 'Error al obtener el usuario', error });
    }
  }

  async createUser(req: Request, res: Response) {
    try {
      const { name, email, role, specialty } = req.body;
      const newUser = await userUseCase.createUser({ name, email, role, specialty });
      res.status(201).json(newUser);
    } catch (error) {
        console.log(error)
      res.status(500).json({ message: 'Error al crear el usuario', error });
    }
  }

  async updateUser(req: Request, res: Response) {
    try {
      const userId = req.params.id;
      const updatedData = req.body;
      const updatedUser = await userUseCase.updateUser(userId, updatedData);
      if (updatedUser) {
        res.status(200).json(updatedUser);
      } else {
        res.status(404).json({ message: 'Usuario no encontrado' });
      }
    } catch (error) {
      res.status(500).json({ message: 'Error al actualizar el usuario', error });
    }
  }

  async deleteUser(req: Request, res: Response) {
    try {
      const userId = req.params.id;
      await userUseCase.deleteUser(userId);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Error al eliminar el usuario', error });
    }
  }
}
