export enum UserTypeEnum {
    STUDENT = 'STUDENT',
    TEACHER = 'TEACHER',
}
  