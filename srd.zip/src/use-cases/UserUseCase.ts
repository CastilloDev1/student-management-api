import { UserRepository } from '../repositories/UserRepository';
import { UserTypeEnum } from '../utils/enums/UserTypeEnums';

export class UserUseCase {
  private userRepository: UserRepository;

  constructor() {
    this.userRepository = new UserRepository();
  }

  async getAllUsers() {
    return await this.userRepository.findAll();
  }

  async getUserById(id: string) {
    return this.userRepository.findById(id);
  }

  async createUser(data: { name: string; email: string; role: UserTypeEnum, specialty?: string }) {
    return this.userRepository.createUser(data);
  }

  async updateUser(id: string, data: Partial<{ name: string; email: string }>) {
    return this.userRepository.update(id, data);
  }

  async deleteUser(id: string) {
    await this.userRepository.delete(id);
  }
}
