import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  // Crear un tipo de usuario
  const userType = await prisma.user_types.create({
    data: { type_name: 'student' },
  });

  // Crear un usuario
  const user = await prisma.users.create({
    data: {
      name: 'John Doe',
      email: 'john.doe@example.com',
      user_type_id: userType.id,
    },
  });

  // Crear un estudiante relacionado con el usuario
  const student = await prisma.students.create({
    data: {
      user_id: user.id,
      enrollment: 'prueba'
    },
  });

  console.log('Student created:', student);

  // Consultar el estudiante junto con el usuario relacionado
  const studentWithUser = await prisma.students.findUnique({
    where: { id: student.id },
    include: { users: true },
  });

  console.log('Student with user:', studentWithUser);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
