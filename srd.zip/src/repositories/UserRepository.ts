import { PrismaClient, users  } from '@prisma/client';
import { UserTypeEnum } from '../utils/enums/UserTypeEnums';

const prisma = new PrismaClient();

export class UserRepository {
  
  async findAll(): Promise<users[]> {
    return await prisma.users.findMany();
  }

  async findById(id: string): Promise<users | null> {
    return prisma.users.findUnique({
      where: { id },
    });
  }

  async createUser(data: { name: string; email: string; role: UserTypeEnum; specialty?: string }) {
    return prisma.users.create({
      data: {
        name: data.name,
        email: data.email,
        role: data.role
      },
    });
  }

  async update(id: string, data: Partial<users>): Promise<users> {
    return prisma.users.update({
      where: { id },
      data,
    });
  }

  async delete(id: string): Promise<void> {
    await prisma.users.delete({
      where: { id },
    });
  }
}