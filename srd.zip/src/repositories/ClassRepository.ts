import { PrismaClient, classes } from '@prisma/client';
const prisma = new PrismaClient();

export class ClassRepository {
  async createClass(data: { name: string; schedule: string; teacher_id: string; subject_id: string }): Promise<classes> {
    return prisma.classes.create({ data });
  }

  async findAllClasses(): Promise<classes[]> {
    return prisma.classes.findMany();
  }

  async findClassById(id: string): Promise<classes | null> {
    return prisma.classes.findUnique({ where: { id } });
  }

  async updateClass(id: string, data: { name?: string; schedule?: string; teacherId?: string; subjectId?: string }): Promise<classes> {
    return prisma.classes.update({ where: { id }, data });
  }

  async deleteClass(id: string): Promise<classes> {
    return prisma.classes.delete({ where: { id } });
  }

  async findClassesWithDetails(): Promise<classes[]> {
    return prisma.classes.findMany({
      include: {
        teacher: {
          select: {
            id: true,
            name: true,
          },
        },
        students: {
          include: {
            student: {
              select: {
                id: true,
                name: true,
              },
            },
          },
        },
        subject: true,
      },
    });
  };

  async getClassWithEnrollments(classId: string): Promise<any> {
    return prisma.classes.findUnique({
      where: { id: classId },
      include: {
        teacher: {
          select: {
            name: true,
          },
        },
        students: {
          include: {
            student: {
              select: {
                name: true,
              },
            },
          },
        },
      },
    });
  }
}
