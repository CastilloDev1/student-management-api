INSERT INTO users (id, name, email, role, updated_at) VALUES 
  ('11111111-1111-1111-1111-111111111111', 'Juan Pérez', 'juan.perez@example.com', 'STUDENT', NOW()),
  ('22222222-2222-2222-2222-222222222222', 'María López', 'maria.lopez@example.com', 'STUDENT', NOW()),
  ('33333333-3333-3333-3333-333333333333', 'Carlos Sánchez', 'carlos.sanchez@example.com', 'STUDENT', NOW()),
  ('44444444-4444-4444-4444-444444444444', 'Ana Torres', 'ana.torres@example.com', 'STUDENT', NOW()),
  ('55555555-5555-5555-5555-555555555555', 'Fabian Castillo', 'fabian.castillo@example.com', 'STUDENT', NOW()),
  ('66666666-6666-6666-6666-666666666666', 'Andrés Forte', 'andres.forte@example.com', 'TEACHER', NOW()),
  ('77777777-7777-7777-7777-777777777777', 'Sofia Rodriguez', 'sofia.rodriguez@example.com', 'TEACHER', NOW()),
  ('88888888-8888-8888-8888-888888888888', 'Daniel Cruz', 'daniel.cruz@example.com', 'TEACHER', NOW()),
  ('99999999-9999-9999-9999-999999999999', 'Juan Vaca', 'juan.vaca@example.com', 'TEACHER', NOW()),
  ('12121212-1212-1212-1212-121212121212', 'Ximena Beltran', 'ximena.beltran@example.com', 'TEACHER', NOW());

INSERT INTO subjects (id, name, code, credits) VALUES 
  ('1a1a1a1a-1a1a-1a1a-1a1a-1a1a1a1a1a1a', 'Álgebra', 'ALG101', 3),
  ('2a2a2a2a-2a2a-2a2a-2a2a-2a2a2a2a2a2a', 'Física Avanzada', 'PHY201', 3),
  ('3a3a3a3a-3a3a-3a3a-3a3a-3a3a3a3a3a3a', 'Programación I', 'PROG301', 3),
  ('4a4a4a4a-4a4a-4a4a-4a4a-4a4a4a4a4a4a', 'Algortimos', 'ALG401', 3),
  ('5a5a5a5a-5a5a-5a5a-5a5a-5a5a5a5a5a5a', 'Lectiva Deportes', 'LEC501', 3),
  ('6a6a6a6a-6a6a-6a6a-6a6a-6a6a6a6a6a6a', 'Inglés', 'ING601', 3),
  ('7a7a7a7a-7a7a-7a7a-7a7a-7a7a7a7a7a7a', 'UML', 'UML701', 3),
  ('8a8a8a8a-8a8a-8a8a-8a8a-8a8a8a8a8a8a', 'POO', 'POO801', 3),
  ('9a9a9a9a-9a9a-9a9a-9a9a-9a9a9a9a9a9a', 'Comprensión de Textos', 'CDT901', 3),
  ('0a0a0a0a-0a0a-0a0a-0a0a-0a0a0a0a0a0a', 'Circuitos básicos', 'CE001', 3);


  INSERT INTO classes (id, name, schedule, teacher_id, subject_id) VALUES 
  ('1b1b1b1b-1b1b-1b1b-1b1b-1b1b1b1b1b1b', 'Álgebra Lineal', 'Lunes y Miércoles 10:00-12:00', '66666666-6666-6666-6666-666666666666', '1a1a1a1a-1a1a-1a1a-1a1a-1a1a1a1a1a1a'),
  ('2b2b2b2b-2b2b-2b2b-2b2b-2b2b2b2b2b2b', 'Fisica Avanzada para dummys', 'Lunes y Miércoles 14:00-16:00', '77777777-7777-7777-7777-777777777777', '2a2a2a2a-2a2a-2a2a-2a2a-2a2a2a2a2a2a'),
  ('3b3b3b3b-3b3b-3b3b-3b3b-3b3b3b3b3b3b', 'Analisis y desarrollo', 'Martes y Jueves 10:00-12:00', '88888888-8888-8888-8888-888888888888', '3a3a3a3a-3a3a-3a3a-3a3a-3a3a3a3a3a3a'),
  ('4b4b4b4b-4b4b-4b4b-4b4b-4b4b4b4b4b4b', 'Scripts & lógica', 'Martes y Jueves 14:00-16:00', '99999999-9999-9999-9999-999999999999', '4a4a4a4a-4a4a-4a4a-4a4a-4a4a4a4a4a4a'),
  ('5b5b5b5b-5b5b-5b5b-5b5b-5b5b5b5b5b5b', 'Lectivas educacionales', 'Martes y Jueves 16:00-18:00', '12121212-1212-1212-1212-121212121212', '5a5a5a5a-5a5a-5a5a-5a5a-5a5a5a5a5a5a'),
  ('6b6b6b6b-6b6b-6b6b-6b6b-6b6b6b6b6b6b', 'Inglés principiantes I', 'Jueves 10:00-12:00', '66666666-6666-6666-6666-666666666666', '6a6a6a6a-6a6a-6a6a-6a6a-6a6a6a6a6a6a'),
  ('7b7b7b7b-7b7b-7b7b-7b7b-7b7b7b7b7b7b', 'Diagramación', 'Jueves 14:00-16:00', '77777777-7777-7777-7777-777777777777', '7a7a7a7a-7a7a-7a7a-7a7a-7a7a7a7a7a7a'),
  ('8b8b8b8b-8b8b-8b8b-8b8b-8b8b8b8b8b8b', 'Programación orientada a objetos', 'Jueves 16:00-18:00', '88888888-8888-8888-8888-888888888888', '8a8a8a8a-8a8a-8a8a-8a8a-8a8a8a8a8a8a'),
  ('9b9b9b9b-9b9b-9b9b-9b9b-9b9b9b9b9b9b', 'Español literario', 'Viernes 09:00-11:00', '99999999-9999-9999-9999-999999999999', '9a9a9a9a-9a9a-9a9a-9a9a-9a9a9a9a9a9a'),
  ('0b0b0b0b-0b0b-0b0b-0b0b-0b0b0b0b0b0b', 'Circuito electronicos', 'Viernes 14:00-16:00', '12121212-1212-1212-1212-121212121212', '0a0a0a0a-0a0a-0a0a-0a0a-0a0a0a0a0a0a');

  INSERT INTO class_enrollments (id, class_id, student_id) VALUES 
  ('1c1c1c1c-1c1c-1c1c-1c1c-1c1c1c1c1c1c', '1b1b1b1b-1b1b-1b1b-1b1b-1b1b1b1b1b1b', '11111111-1111-1111-1111-111111111111'),
  ('2c2c2c2c-2c2c-2c2c-2c2c-2c2c2c2c2c2c', '2b2b2b2b-2b2b-2b2b-2b2b-2b2b2b2b2b2b', '11111111-1111-1111-1111-111111111111'),
  ('3c3c3c3c-3c3c-3c3c-3c3c-3c3c3c3c3c3c', '3b3b3b3b-3b3b-3b3b-3b3b-3b3b3b3b3b3b', '11111111-1111-1111-1111-111111111111'),
  ('4c4c4c4c-4c4c-4c4c-4c4c-4c4c4c4c4c4c', '4b4b4b4b-4b4b-4b4b-4b4b-4b4b4b4b4b4b', '22222222-2222-2222-2222-222222222222'),
  ('5c5c5c5c-5c5c-5c5c-5c5c-5c5c5c5c5c5c', '5b5b5b5b-5b5b-5b5b-5b5b-5b5b5b5b5b5b', '22222222-2222-2222-2222-222222222222'),
  ('6c6c6c6c-6c6c-6c6c-6c6c-6c6c6c6c6c6c', '6b6b6b6b-6b6b-6b6b-6b6b-6b6b6b6b6b6b', '22222222-2222-2222-2222-222222222222'),
  ('7c7c7c7c-7c7c-7c7c-7c7c-7c7c7c7c7c7c', '7b7b7b7b-7b7b-7b7b-7b7b-7b7b7b7b7b7b', '33333333-3333-3333-3333-333333333333'),
  ('8c8c8c8c-8c8c-8c8c-8c8c-8c8c8c8c8c8c', '9b9b9b9b-9b9b-9b9b-9b9b-9b9b9b9b9b9b', '33333333-3333-3333-3333-333333333333'),
  ('9c9c9c9c-9c9c-9c9c-9c9c-9c9c9c9c9c9c', '0b0b0b0b-0b0b-0b0b-0b0b-0b0b0b0b0b0b', '33333333-3333-3333-3333-333333333333'),
  ('10c10c10c10c-10c10c-10c10c-10c10c-10c10c10c10c10c10c', '1b1b1b1b-1b1b-1b1b-1b1b-1b1b1b1b1b1b', '44444444-4444-4444-4444-444444444444'),
  ('11c11c11c11c-11c11c-11c11c-11c11c-11c11c11c11c11c11c', '4b4b4b4b-4b4b-4b4b-4b4b-4b4b4b4b4b4b', '44444444-4444-4444-4444-444444444444'),
  ('12c12c12c12c-12c12c-12c12c-12c12c-12c12c12c12c12c12c', '3b3b3b3b-3b3b-3b3b-3b3b-3b3b3b3b3b3b', '44444444-4444-4444-4444-444444444444');



