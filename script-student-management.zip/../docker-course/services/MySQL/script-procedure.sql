CREATE PROCEDURE GetStudentEnrollmentsWithCosts(IN studentIdParam VARCHAR(36))
BEGIN
    SELECT 
        ce.id AS enrollmentId,
        c.name AS className,
        s.name AS subjectName,
        s.credits AS subjectCredits,
        (s.credits * 150) AS costInUSD, -- Cálculo del costo en USD
        u.name AS teacherName,
        c.schedule AS classSchedule
    FROM 
        class_enrollments ce
    JOIN 
        classes c ON ce.class_id = c.id
    JOIN 
        subjects s ON c.subject_id = s.id
    JOIN 
        users u ON c.teacher_id = u.id
    WHERE 
        ce.student_id = studentIdParam COLLATE utf8mb4_unicode_ci;
END;