# Tener en cuenta!
- En caso de falla en la insercción de datos. Por favor, ejecutar uno a uno. (Se reacomodan los scripts en orden para que no tenga problemas de ejecución.)