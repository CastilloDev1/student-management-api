-- Crear tabla de tipos de usuarios primero
CREATE TABLE user_types (
  id INT PRIMARY KEY AUTO_INCREMENT,
  type_name VARCHAR(50) UNIQUE NOT NULL
);

-- Inserción de tipos de usuario predeterminados
INSERT INTO user_types (type_name) VALUES ('student'), ('teacher');

-- Crear tabla de usuarios, que hace referencia a la tabla de tipos de usuarios
CREATE TABLE users (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(250) NOT NULL,
  email VARCHAR(250) UNIQUE NOT NULL,
  user_type_id INT NOT NULL,
  FOREIGN KEY (user_type_id) REFERENCES user_types(id)
);

-- Crear tabla de estudiantes, que hace referencia a la tabla de usuarios
CREATE TABLE students (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id BIGINT NOT NULL,
  enrollment VARCHAR(50) UNIQUE NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Crear tabla de profesores, que hace referencia a la tabla de usuarios
CREATE TABLE teachers (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id BIGINT NOT NULL,
  specialty VARCHAR(150),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Crear tabla de materias
CREATE TABLE subjects (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(250) NOT NULL,
  code VARCHAR(50) UNIQUE NOT NULL,
  credits INT NOT NULL CHECK (credits = 3),
  cost DECIMAL(10, 2) NOT NULL
);

-- Crear tabla de clases, que hace referencia a las tablas de materias y profesores
CREATE TABLE classes (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  subject_id BIGINT NOT NULL,
  teacher_id BIGINT,
  schedule VARCHAR(100),
  slots INT NOT NULL CHECK (slots > 0),
  price_in_euros DECIMAL(10, 2) NOT NULL,
  FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
  FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE SET NULL
);

-- Crear tabla de relación entre estudiantes y clases
CREATE TABLE students_classes (
  student_id BIGINT NOT NULL,
  class_id BIGINT NOT NULL,
  PRIMARY KEY (student_id, class_id),
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE
);

-- Crear tabla de relación entre profesores y clases
CREATE TABLE teachers_classes (
  teacher_id BIGINT NOT NULL,
  class_id BIGINT NOT NULL,
  PRIMARY KEY (teacher_id, class_id),
  FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE CASCADE,
  FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE
);